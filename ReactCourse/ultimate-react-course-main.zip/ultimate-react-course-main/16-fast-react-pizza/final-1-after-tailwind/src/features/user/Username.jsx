function Username() {
  return <div className="hidden text-sm font-semibold md:block">Jonas</div>;
}

export default Username;
