export default function Logo() {
  return <h1>🏝️ Far Away 🧳</h1>;
}
